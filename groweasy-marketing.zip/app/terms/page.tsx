import Link from "next/link"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function TermsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl space-y-8">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl">Terms of Service</h1>
                <p className="text-muted-foreground">Last updated: March 16, 2023</p>
              </div>
              <div className="space-y-6">
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">1. Introduction</h2>
                  <p className="text-muted-foreground">
                    Welcome to GrowEasy Marketing. These Terms of Service govern your use of our website and services.
                    By accessing or using our services, you agree to be bound by these Terms.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">2. Services</h2>
                  <p className="text-muted-foreground">
                    GrowEasy Marketing provides digital marketing services including but not limited to content
                    marketing, SEO optimization, social media marketing, email marketing, brand strategy, and analytics
                    & reporting.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">3. Client Responsibilities</h2>
                  <p className="text-muted-foreground">
                    Clients are responsible for providing accurate information, timely feedback, and necessary access to
                    accounts required for service delivery. Clients are also responsible for ensuring that all content
                    provided complies with applicable laws and regulations.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">4. Payment Terms</h2>
                  <p className="text-muted-foreground">
                    Payment terms are specified in individual client contracts. Unless otherwise stated, invoices are
                    due within 30 days of issuance. Late payments may incur additional fees.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">5. Intellectual Property</h2>
                  <p className="text-muted-foreground">
                    All intellectual property created by GrowEasy Marketing remains the property of GrowEasy Marketing
                    until full payment is received, at which point specified deliverables become the property of the
                    client. GrowEasy Marketing retains the right to use non-confidential work in its portfolio.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">6. Confidentiality</h2>
                  <p className="text-muted-foreground">
                    GrowEasy Marketing agrees to maintain the confidentiality of all client information and data. We
                    will not disclose confidential information to third parties without explicit permission.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">7. Limitation of Liability</h2>
                  <p className="text-muted-foreground">
                    GrowEasy Marketing is not liable for any indirect, incidental, or consequential damages arising from
                    the use of our services. Our total liability shall not exceed the amount paid by the client for the
                    services in question.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">8. Termination</h2>
                  <p className="text-muted-foreground">
                    Either party may terminate services with written notice as specified in individual client contracts.
                    Upon termination, the client is responsible for payment of all services rendered up to the
                    termination date.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">9. Governing Law</h2>
                  <p className="text-muted-foreground">
                    These Terms are governed by the laws of the State of New York. Any disputes arising from these Terms
                    shall be resolved in the courts of New York.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">10. Changes to Terms</h2>
                  <p className="text-muted-foreground">
                    GrowEasy Marketing reserves the right to modify these Terms at any time. Changes will be effective
                    upon posting to our website. Continued use of our services after changes constitutes acceptance of
                    the modified Terms.
                  </p>
                </div>
              </div>
              <div className="border-t pt-8">
                <p className="text-muted-foreground">
                  If you have any questions about these Terms, please contact us at{" "}
                  <Link href="mailto:legal@groweasymarketing.com" className="text-primary underline">
                    legal@groweasymarketing.com
                  </Link>
                  .
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

