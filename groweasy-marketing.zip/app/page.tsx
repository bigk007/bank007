import Link from "next/link"
import { ArrowRight, CheckCircle, Mail, MapPin, Phone } from "lucide-react"
import { Suspense } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AnimatedCard } from "@/components/animated-card"
import { AnimatedSection } from "@/components/animated-section"
import { AnimatedText } from "@/components/animated-text"
import { AnimatedButton } from "@/components/animated-button"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <AnimatedSection className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <AnimatedText
                    text="Grow Your Business with Smart Marketing"
                    className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none"
                    tag="h1"
                  />
                  <AnimatedText
                    text="We help businesses like yours reach new heights with data-driven marketing strategies that deliver real results."
                    className="max-w-[600px] text-muted-foreground md:text-xl"
                    tag="p"
                    delay={0.5}
                  />
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <AnimatedButton size="lg" asChild className="px-8" delay={0.8}>
                    <Link href="/contact">
                      Get Started
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </AnimatedButton>
                  <AnimatedButton size="lg" variant="outline" asChild delay={1}>
                    <Link href="/services">Learn More</Link>
                  </AnimatedButton>
                </div>
              </div>
              <Suspense fallback={<div className="h-[550px] w-full bg-muted/20 animate-pulse rounded-xl"></div>}>
                <div className="relative">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/20 to-primary/10 rounded-xl blur-xl opacity-50 group-hover:opacity-75 transition duration-500"></div>
                  <img
                    src="/placeholder.svg?height=550&width=550"
                    alt="Marketing Dashboard"
                    width={550}
                    height={550}
                    className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last relative z-10 shadow-xl"
                  />
                </div>
              </Suspense>
            </div>
          </div>
        </AnimatedSection>

        {/* Services Section */}
        <AnimatedSection className="w-full py-12 md:py-24 lg:py-32 bg-background" id="services" delay={0.2}>
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
                  Our Services
                </div>
                <AnimatedText
                  text="Comprehensive Marketing Solutions"
                  className="text-3xl font-bold tracking-tighter md:text-4xl"
                  tag="h2"
                />
                <AnimatedText
                  text="We offer a full range of marketing services to help your business grow and succeed in today's competitive market."
                  className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed"
                  tag="p"
                  delay={0.3}
                />
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
              {[
                {
                  title: "Content Marketing",
                  description:
                    "Engaging content that resonates with your audience and drives conversions through blogs, articles, and social media.",
                  icon: (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M12 20h9"></path>
                      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                    </svg>
                  ),
                },
                {
                  title: "SEO Optimization",
                  description:
                    "Improve your search engine rankings and drive organic traffic with our data-driven SEO strategies.",
                  icon: (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="m16 10-4 4-2-2"></path>
                    </svg>
                  ),
                },
                {
                  title: "Social Media",
                  description:
                    "Build your brand presence and engage with your audience through strategic social media marketing campaigns.",
                  icon: (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M5.51 18.51 12 12l6.49 6.51"></path>
                      <path d="m5.51 5.51 12.98 12.98"></path>
                      <path d="M18.49 5.51 12 12"></path>
                    </svg>
                  ),
                },
                {
                  title: "Email Marketing",
                  description:
                    "Connect directly with your customers through personalized email campaigns that drive engagement and sales.",
                  icon: (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                      <polyline points="3.29 7 12 12 20.71 7"></polyline>
                      <line x1="12" y1="22" x2="12" y2="12"></line>
                    </svg>
                  ),
                },
                {
                  title: "Brand Strategy",
                  description:
                    "Develop a strong brand identity that resonates with your target audience and sets you apart from competitors.",
                  icon: (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M17 2H7a5 5 0 0 0-5 5v10a5 5 0 0 0 5 5h10a5 5 0 0 0 5-5V7a5 5 0 0 0-5-5Z"></path>
                      <path d="m4.5 16.5 5-5c.83-.83 2.17-.83 3 0l5 5"></path>
                      <path d="m15 12 2-2c.83-.83 2.17-.83 3 0l.5.5"></path>
                    </svg>
                  ),
                },
                {
                  title: "Analytics & Reporting",
                  description:
                    "Gain valuable insights into your marketing performance with comprehensive analytics and detailed reporting.",
                  icon: (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M3 3v18h18"></path>
                      <path d="m19 9-5 5-4-4-3 3"></path>
                    </svg>
                  ),
                },
              ].map((service, index) => (
                <AnimatedCard key={service.title} delay={index + 1}>
                  <Card className="h-full transition-all duration-300 hover:border-primary/50">
                    <CardHeader className="flex flex-row items-center gap-4 pb-2">
                      <div className="bg-primary/20 p-2 rounded-full">{service.icon}</div>
                      <CardTitle>{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{service.description}</p>
                    </CardContent>
                  </Card>
                </AnimatedCard>
              ))}
            </div>
            <div className="flex justify-center mt-8">
              <AnimatedButton size="lg" asChild delay={7}>
                <Link href="/services">
                  View All Services
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </AnimatedButton>
            </div>
          </div>
        </AnimatedSection>

        {/* Why Choose Us Section */}
        <AnimatedSection className="w-full py-12 md:py-24 lg:py-32 bg-muted/50" delay={0.4}>
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <AnimatedText
                  text="Why Choose GrowEasy Marketing"
                  className="text-3xl font-bold tracking-tighter md:text-4xl"
                  tag="h2"
                />
                <AnimatedText
                  text="We're not just another marketing agency. Here's what sets us apart."
                  className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed"
                  tag="p"
                  delay={0.3}
                />
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8">
              {[
                {
                  title: "Data-Driven Approach",
                  description:
                    "We make decisions based on real data, not guesswork, ensuring your marketing budget is spent effectively.",
                },
                {
                  title: "Tailored Strategies",
                  description:
                    "Every business is unique. We create custom marketing plans designed specifically for your goals and audience.",
                },
                {
                  title: "Transparent Reporting",
                  description:
                    "We provide clear, comprehensive reports so you always know exactly how your campaigns are performing.",
                },
                {
                  title: "Expert Team",
                  description:
                    "Our team of marketing specialists brings years of experience across various industries and platforms.",
                },
                {
                  title: "Results-Focused",
                  description:
                    "We measure success by the results we deliver – increased traffic, leads, and ultimately, revenue for your business.",
                },
                {
                  title: "Ongoing Support",
                  description:
                    "We're partners in your success, providing continuous support and adjusting strategies as your business evolves.",
                },
              ].map((feature, index) => (
                <AnimatedCard
                  key={feature.title}
                  delay={index + 1}
                  className="bg-background/50 hover:bg-background transition-colors duration-300"
                >
                  <div className="flex flex-col items-center space-y-2 rounded-lg p-4">
                    <div className="bg-primary/20 p-3 rounded-full">
                      <CheckCircle className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold">{feature.title}</h3>
                    <p className="text-center text-muted-foreground">{feature.description}</p>
                  </div>
                </AnimatedCard>
              ))}
            </div>
            <div className="flex justify-center mt-8">
              <AnimatedButton size="lg" asChild delay={7}>
                <Link href="/about">
                  Learn More About Us
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </AnimatedButton>
            </div>
          </div>
        </AnimatedSection>

        {/* Testimonials Section */}
        <AnimatedSection className="w-full py-12 md:py-24 lg:py-32 bg-background" id="testimonials" delay={0.6}>
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
                  Testimonials
                </div>
                <AnimatedText
                  text="What Our Clients Say"
                  className="text-3xl font-bold tracking-tighter md:text-4xl"
                  tag="h2"
                />
                <AnimatedText
                  text="Don't just take our word for it. Here's what our clients have to say about working with GrowEasy Marketing."
                  className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed"
                  tag="p"
                  delay={0.3}
                />
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
              {[
                {
                  name: "Sarah Johnson",
                  role: "CEO, TechStart Inc.",
                  testimonial:
                    "GrowEasy transformed our marketing strategy. Within just three months, we saw a 40% increase in qualified leads and a significant boost in our online presence.",
                },
                {
                  name: "Michael Chen",
                  role: "Marketing Director, Retail Solutions",
                  testimonial:
                    "The team at GrowEasy truly understands our industry. Their content marketing strategy has positioned us as thought leaders and significantly increased our customer engagement.",
                },
                {
                  name: "Emily Rodriguez",
                  role: "Founder, Wellness Collective",
                  testimonial:
                    "As a small business, we needed a marketing partner who could maximize our limited budget. GrowEasy delivered beyond our expectations, helping us compete with much larger competitors.",
                },
              ].map((testimonial, index) => (
                <AnimatedCard key={testimonial.name} delay={index + 1} className="bg-muted/50">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="relative h-10 w-10 overflow-hidden rounded-full">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Avatar"
                          className="aspect-square h-full w-full"
                        />
                      </div>
                      <div className="grid gap-1">
                        <div className="font-semibold">{testimonial.name}</div>
                        <div className="text-xs text-muted-foreground">{testimonial.role}</div>
                      </div>
                    </div>
                    <div className="mt-4">
                      <p className="text-sm text-muted-foreground">"{testimonial.testimonial}"</p>
                    </div>
                  </CardContent>
                </AnimatedCard>
              ))}
            </div>
            <div className="flex justify-center mt-8">
              <AnimatedButton size="lg" asChild delay={4}>
                <Link href="/testimonials">
                  View All Testimonials
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </AnimatedButton>
            </div>
          </div>
        </AnimatedSection>

        {/* Contact Section */}
        <AnimatedSection className="w-full py-12 md:py-24 lg:py-32 bg-muted" id="contact" delay={0.8}>
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
                  Contact Us
                </div>
                <AnimatedText
                  text="Ready to Grow Your Business?"
                  className="text-3xl font-bold tracking-tighter md:text-4xl"
                  tag="h2"
                />
                <AnimatedText
                  text="Get in touch with our team to discuss how we can help you achieve your marketing goals."
                  className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed"
                  tag="p"
                  delay={0.3}
                />
              </div>
            </div>
            <div className="mx-auto grid max-w-6xl grid-cols-1 gap-8 lg:grid-cols-2 mt-8">
              <div className="space-y-6">
                {[
                  {
                    icon: <MapPin className="h-6 w-6 text-primary" />,
                    title: "Our Location",
                    content: "123 Marketing Street, Business District, NY 10001",
                  },
                  {
                    icon: <Mail className="h-6 w-6 text-primary" />,
                    title: "Email Us",
                    content: "info@groweasymarketing.com",
                  },
                  {
                    icon: <Phone className="h-6 w-6 text-primary" />,
                    title: "Call Us",
                    content: "(555) 123-4567",
                  },
                ].map((item, index) => (
                  <AnimatedCard key={item.title} delay={index + 1} className="bg-transparent border-0 shadow-none">
                    <div className="flex items-center gap-4">
                      <div className="bg-primary/20 p-3 rounded-full">{item.icon}</div>
                      <div>
                        <h3 className="text-xl font-bold">{item.title}</h3>
                        <p className="text-muted-foreground">{item.content}</p>
                      </div>
                    </div>
                  </AnimatedCard>
                ))}
                <AnimatedCard delay={4} className="border bg-background hover:shadow-lg">
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-4">Business Hours</h3>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>Monday - Friday</div>
                      <div>9:00 AM - 6:00 PM</div>
                      <div>Saturday</div>
                      <div>10:00 AM - 4:00 PM</div>
                      <div>Sunday</div>
                      <div>Closed</div>
                    </div>
                  </div>
                </AnimatedCard>
              </div>
              <AnimatedCard delay={5} className="border bg-background hover:shadow-lg">
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-4">Send Us a Message</h3>
                  <form className="grid gap-4">
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div className="grid gap-2">
                        <label htmlFor="first-name" className="text-sm font-medium leading-none">
                          First name
                        </label>
                        <Input
                          id="first-name"
                          placeholder="Enter your first name"
                          className="transition-all duration-300 focus:border-primary focus:ring-2 focus:ring-primary/20"
                        />
                      </div>
                      <div className="grid gap-2">
                        <label htmlFor="last-name" className="text-sm font-medium leading-none">
                          Last name
                        </label>
                        <Input
                          id="last-name"
                          placeholder="Enter your last name"
                          className="transition-all duration-300 focus:border-primary focus:ring-2 focus:ring-primary/20"
                        />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <label htmlFor="email" className="text-sm font-medium leading-none">
                        Email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        className="transition-all duration-300 focus:border-primary focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                    <div className="grid gap-2">
                      <label htmlFor="phone" className="text-sm font-medium leading-none">
                        Phone
                      </label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="Enter your phone number"
                        className="transition-all duration-300 focus:border-primary focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                    <div className="grid gap-2">
                      <label htmlFor="message" className="text-sm font-medium leading-none">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        placeholder="Enter your message"
                        className="min-h-[120px] transition-all duration-300 focus:border-primary focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                    <AnimatedButton type="submit" className="w-full" delay={0.5}>
                      Send Message
                    </AnimatedButton>
                  </form>
                </div>
              </AnimatedCard>
            </div>
          </div>
        </AnimatedSection>
      </main>
      <Footer />
    </div>
  )
}

