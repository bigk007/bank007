import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    About GrowEasy Marketing
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    We're a team of marketing experts dedicated to helping businesses grow through innovative,
                    data-driven strategies.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" asChild className="px-8">
                    <Link href="/contact">
                      Contact Us
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild>
                    <Link href="/services">Our Services</Link>
                  </Button>
                </div>
              </div>
              <img
                src="/placeholder.svg?height=550&width=550"
                alt="Our Team"
                width={550}
                height={550}
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
              />
            </div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
                  Our Story
                </div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">How We Started</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Founded in 2015, GrowEasy Marketing began with a simple mission: to provide businesses with effective,
                  transparent marketing solutions that deliver real results.
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl mt-8 space-y-6">
              <p className="text-muted-foreground">
                Our founder, Jane Smith, recognized a gap in the market. Too many businesses were spending money on
                marketing without seeing measurable results. Marketing agencies were promising the world but delivering
                little in terms of actual business growth.
              </p>
              <p className="text-muted-foreground">
                Jane assembled a team of marketing experts who shared her vision: to create a marketing agency that
                prioritized data, transparency, and most importantly, results. We believe that marketing should be an
                investment, not an expense.
              </p>
              <p className="text-muted-foreground">
                Since then, we've grown from a small team of three to a full-service marketing agency with over 30
                specialists across content, SEO, social media, email marketing, and analytics. We've helped hundreds of
                businesses across various industries achieve their growth goals.
              </p>
              <p className="text-muted-foreground">
                Today, GrowEasy Marketing continues to evolve with the changing digital landscape, but our core mission
                remains the same: to help businesses grow through smart, effective marketing strategies.
              </p>
            </div>
          </div>
        </section>

        {/* Our Team Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
                  Our Team
                </div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Meet the Experts</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our diverse team of marketing specialists brings years of experience and passion to every project.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8">
              <div className="flex flex-col items-center space-y-4">
                <div className="relative h-40 w-40 overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="Team Member"
                    className="aspect-square h-full w-full object-cover"
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold">Jane Smith</h3>
                  <p className="text-sm text-muted-foreground">Founder & CEO</p>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4">
                <div className="relative h-40 w-40 overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="Team Member"
                    className="aspect-square h-full w-full object-cover"
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold">Michael Johnson</h3>
                  <p className="text-sm text-muted-foreground">Head of SEO</p>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4">
                <div className="relative h-40 w-40 overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="Team Member"
                    className="aspect-square h-full w-full object-cover"
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold">Sarah Williams</h3>
                  <p className="text-sm text-muted-foreground">Content Director</p>
                </div>
              </div>
            </div>
            <div className="flex justify-center mt-12">
              <Button size="lg" asChild>
                <Link href="/contact">
                  Work With Our Team
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

