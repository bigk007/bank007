import { Input } from "@/components/ui/input"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function BlogPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Marketing Insights Blog
                </h1>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Expert tips, strategies, and insights to help you grow your business.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Blog Posts Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog Post"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-2">March 15, 2023</p>
                    <h3 className="text-xl font-bold mb-2">10 SEO Strategies That Actually Work in 2023</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Learn the latest SEO strategies that are driving real results for businesses in today's
                      competitive digital landscape.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/blog/seo-strategies">Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog Post"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-2">February 28, 2023</p>
                    <h3 className="text-xl font-bold mb-2">The Ultimate Guide to Content Marketing</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Everything you need to know about creating a content marketing strategy that engages your audience
                      and drives conversions.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/blog/content-marketing-guide">Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog Post"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-2">January 15, 2023</p>
                    <h3 className="text-xl font-bold mb-2">Social Media Trends to Watch in 2023</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Stay ahead of the curve with these emerging social media trends that are shaping the digital
                      marketing landscape.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/blog/social-media-trends">Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog Post"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-2">December 10, 2022</p>
                    <h3 className="text-xl font-bold mb-2">
                      Email Marketing Best Practices for Higher Conversion Rates
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Discover proven email marketing strategies that can help you increase open rates, click-through
                      rates, and conversions.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/blog/email-marketing-best-practices">Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog Post"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-2">November 22, 2022</p>
                    <h3 className="text-xl font-bold mb-2">How to Measure Marketing ROI: A Complete Guide</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Learn how to accurately measure the return on investment of your marketing campaigns to optimize
                      your strategy.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/blog/measuring-marketing-roi">Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Blog Post"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-2">October 15, 2022</p>
                    <h3 className="text-xl font-bold mb-2">
                      Building a Brand That Stands Out: Strategies for Small Businesses
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Practical branding strategies for small businesses looking to make a big impact in their market.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/blog/building-a-brand">Read More</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Subscribe to Our Newsletter</h2>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Get the latest marketing insights, tips, and strategies delivered straight to your inbox.
                </p>
              </div>
              <div className="mx-auto w-full max-w-md space-y-2">
                <form className="flex space-x-2">
                  <Input type="email" placeholder="Enter your email" className="max-w-lg flex-1" />
                  <Button type="submit">Subscribe</Button>
                </form>
                <p className="text-xs text-muted-foreground">We respect your privacy. Unsubscribe at any time.</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

