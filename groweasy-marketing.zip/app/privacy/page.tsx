import Link from "next/link"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function PrivacyPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl space-y-8">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl">Privacy Policy</h1>
                <p className="text-muted-foreground">Last updated: March 16, 2023</p>
              </div>
              <div className="space-y-6">
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">1. Introduction</h2>
                  <p className="text-muted-foreground">
                    At GrowEasy Marketing, we respect your privacy and are committed to protecting your personal data.
                    This Privacy Policy explains how we collect, use, and safeguard your information when you visit our
                    website or use our services.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">2. Information We Collect</h2>
                  <p className="text-muted-foreground">
                    We may collect personal information such as your name, email address, phone number, and company
                    information when you fill out forms on our website, subscribe to our newsletter, or contact us. We
                    also collect usage data through cookies and similar technologies.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">3. How We Use Your Information</h2>
                  <p className="text-muted-foreground">
                    We use your information to provide and improve our services, communicate with you, process
                    transactions, send marketing communications (with your consent), and comply with legal obligations.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">4. Data Sharing and Disclosure</h2>
                  <p className="text-muted-foreground">
                    We may share your information with service providers who help us operate our business, with your
                    consent, to comply with legal obligations, or in connection with a business transfer.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">5. Data Security</h2>
                  <p className="text-muted-foreground">
                    We implement appropriate security measures to protect your personal information from unauthorized
                    access, alteration, disclosure, or destruction.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">6. Your Data Protection Rights</h2>
                  <p className="text-muted-foreground">
                    Depending on your location, you may have rights regarding your personal data, including the right to
                    access, correct, delete, restrict processing, and data portability.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">7. Cookies and Tracking Technologies</h2>
                  <p className="text-muted-foreground">
                    We use cookies and similar tracking technologies to collect information about your browsing
                    activities. You can manage your cookie preferences through your browser settings.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">8. Children's Privacy</h2>
                  <p className="text-muted-foreground">
                    Our services are not intended for individuals under the age of 16. We do not knowingly collect
                    personal information from children.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">9. Changes to This Privacy Policy</h2>
                  <p className="text-muted-foreground">
                    We may update this Privacy Policy from time to time. We will notify you of any changes by posting
                    the new Privacy Policy on this page and updating the "Last updated" date.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">10. Contact Us</h2>
                  <p className="text-muted-foreground">
                    If you have any questions about this Privacy Policy, please contact us at{" "}
                    <Link href="mailto:privacy@groweasymarketing.com" className="text-primary underline">
                      privacy@groweasymarketing.com
                    </Link>
                    .
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

