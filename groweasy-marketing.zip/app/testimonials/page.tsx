import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function TestimonialsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Client Success Stories
                </h1>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Don't just take our word for it. See what our clients have to say about working with GrowEasy
                  Marketing.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2">
              <Card className="bg-muted/50">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="relative h-10 w-10 overflow-hidden rounded-full">
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="Avatar"
                        className="aspect-square h-full w-full"
                      />
                    </div>
                    <div className="grid gap-1">
                      <div className="font-semibold">Sarah Johnson</div>
                      <div className="text-xs text-muted-foreground">CEO, TechStart Inc.</div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-muted-foreground">
                      "GrowEasy transformed our marketing strategy. Within just three months, we saw a 40% increase in
                      qualified leads and a significant boost in our online presence. Their team took the time to
                      understand our business and created a tailored approach that addressed our specific challenges."
                    </p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-muted/50">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="relative h-10 w-10 overflow-hidden rounded-full">
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="Avatar"
                        className="aspect-square h-full w-full"
                      />
                    </div>
                    <div className="grid gap-1">
                      <div className="font-semibold">Michael Chen</div>
                      <div className="text-xs text-muted-foreground">Marketing Director, Retail Solutions</div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-muted-foreground">
                      "The team at GrowEasy truly understands our industry. Their content marketing strategy has
                      positioned us as thought leaders and significantly increased our customer engagement. We've seen a
                      25% increase in website traffic and a 15% increase in conversion rates since working with them."
                    </p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-muted/50">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="relative h-10 w-10 overflow-hidden rounded-full">
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="Avatar"
                        className="aspect-square h-full w-full"
                      />
                    </div>
                    <div className="grid gap-1">
                      <div className="font-semibold">Emily Rodriguez</div>
                      <div className="text-xs text-muted-foreground">Founder, Wellness Collective</div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-muted-foreground">
                      "As a small business, we needed a marketing partner who could maximize our limited budget.
                      GrowEasy delivered beyond our expectations, helping us compete with much larger competitors. Their
                      SEO and social media strategies have been game-changers for our business growth."
                    </p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-muted/50">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="relative h-10 w-10 overflow-hidden rounded-full">
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="Avatar"
                        className="aspect-square h-full w-full"
                      />
                    </div>
                    <div className="grid gap-1">
                      <div className="font-semibold">David Thompson</div>
                      <div className="text-xs text-muted-foreground">COO, Enterprise Solutions</div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-muted-foreground">
                      "We've worked with several marketing agencies in the past, but GrowEasy stands out for their
                      strategic approach and focus on results. Their team is responsive, creative, and truly invested in
                      our success. We've seen a significant ROI from our marketing spend since partnering with them."
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Case Studies Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Featured Case Studies</h2>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Explore detailed case studies of how we've helped businesses achieve their marketing goals.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8">
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Case Study"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">TechStart Inc.</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      How we helped a tech startup increase qualified leads by 40% in just three months.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/contact">Read Case Study</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Case Study"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">Retail Solutions</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      How our content marketing strategy positioned a retail company as an industry thought leader.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/contact">Read Case Study</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-0">
                  <img
                    src="/placeholder.svg?height=200&width=400"
                    alt="Case Study"
                    className="aspect-video w-full object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">Wellness Collective</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      How we helped a small wellness business compete with larger competitors through targeted
                      marketing.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/contact">Read Case Study</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Ready to See Results?</h2>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Join our growing list of satisfied clients and start seeing real results from your marketing efforts.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild className="px-8">
                  <Link href="/contact">
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

