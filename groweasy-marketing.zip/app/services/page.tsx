import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function ServicesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Our Marketing Services
                </h1>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Comprehensive marketing solutions tailored to your business needs and goals.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild className="px-8">
                  <Link href="/contact">
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Content Marketing</CardTitle>
                  <CardDescription>Engaging content that resonates with your audience</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our content marketing services include blog posts, articles, whitepapers, case studies, and more. We
                    create content that educates, entertains, and converts.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li>• Blog content strategy and creation</li>
                    <li>• Long-form content development</li>
                    <li>• Content distribution</li>
                    <li>• Content performance analysis</li>
                  </ul>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contact">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>SEO Optimization</CardTitle>
                  <CardDescription>Improve your search engine rankings</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our SEO services help your business rank higher in search engine results, driving more organic
                    traffic to your website and increasing conversions.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li>• Keyword research and strategy</li>
                    <li>• On-page and off-page optimization</li>
                    <li>• Technical SEO audits</li>
                    <li>• Local SEO for businesses</li>
                  </ul>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contact">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Social Media Marketing</CardTitle>
                  <CardDescription>Build your brand presence on social platforms</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our social media marketing services help you connect with your audience, build brand awareness, and
                    drive engagement across all major platforms.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li>• Social media strategy development</li>
                    <li>• Content creation and scheduling</li>
                    <li>• Community management</li>
                    <li>• Paid social media advertising</li>
                  </ul>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contact">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Email Marketing</CardTitle>
                  <CardDescription>Connect directly with your customers</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our email marketing services help you build and maintain relationships with your customers through
                    personalized, targeted email campaigns.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li>• Email campaign strategy</li>
                    <li>• Newsletter design and creation</li>
                    <li>• Automated email sequences</li>
                    <li>• A/B testing and optimization</li>
                  </ul>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contact">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Brand Strategy</CardTitle>
                  <CardDescription>Develop a strong brand identity</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our brand strategy services help you define your brand's voice, values, and visual identity to
                    create a cohesive brand experience.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li>• Brand positioning and messaging</li>
                    <li>• Visual identity development</li>
                    <li>• Brand guidelines creation</li>
                    <li>• Brand voice and tone definition</li>
                  </ul>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contact">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Analytics & Reporting</CardTitle>
                  <CardDescription>Gain valuable insights into your marketing</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our analytics and reporting services provide you with clear, actionable insights into your marketing
                    performance.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li>• Custom dashboard creation</li>
                    <li>• Regular performance reports</li>
                    <li>• Data analysis and insights</li>
                    <li>• ROI tracking and measurement</li>
                  </ul>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contact">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Ready to Grow Your Business?</h2>
                <p className="max-w-[600px] mx-auto text-muted-foreground md:text-xl">
                  Contact us today to discuss how our marketing services can help you achieve your business goals.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild className="px-8">
                  <Link href="/contact">
                    Contact Us
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/testimonials">See Client Results</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

