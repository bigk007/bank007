"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface AnimatedButtonProps extends React.ComponentProps<typeof Button> {
  children: React.ReactNode
  delay?: number
  className?: string
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  size?: "default" | "sm" | "lg" | "icon"
  is3D?: boolean
}

export function AnimatedButton({
  children,
  delay = 0,
  className = "",
  variant = "default",
  size = "default",
  is3D = true,
  ...props
}: AnimatedButtonProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: delay * 0.1 }}
      viewport={{ once: true }}
      style={{
        transformStyle: is3D ? "preserve-3d" : "flat",
        perspective: "1000px",
      }}
    >
      <Button
        variant={variant}
        size={size}
        className={cn("transition-all duration-300 relative overflow-hidden group", className)}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        style={{
          transform: is3D && isHovered ? "translateZ(5px) translateY(-2px)" : "translateZ(0) translateY(0)",
          transition: "transform 0.2s ease-out",
        }}
        {...props}
      >
        <span className="relative z-10">{children}</span>
        {variant === "default" && (
          <span className="absolute inset-0 bg-primary-foreground/10 transform scale-x-0 origin-left transition-transform duration-300 group-hover:scale-x-100" />
        )}
      </Button>
    </motion.div>
  )
}

