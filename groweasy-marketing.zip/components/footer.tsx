"use client"

import Link from "next/link"
import { Facebook, Instagram, Linkedin, Twitter } from "lucide-react"
import { motion } from "framer-motion"

export function Footer() {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <footer className="w-full border-t bg-background py-8">
      <div className="container px-4 md:px-6">
        <motion.div
          className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <motion.div className="space-y-4" variants={item}>
            <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60 hover:from-primary/80 hover:to-primary transition-all duration-300">
              GrowEasy
            </div>
            <p className="text-sm text-muted-foreground">
              Helping businesses grow with smart, data-driven marketing strategies since 2015.
            </p>
            <div className="flex space-x-4">
              {[
                { icon: <Facebook className="h-5 w-5" />, label: "Facebook" },
                { icon: <Twitter className="h-5 w-5" />, label: "Twitter" },
                { icon: <Instagram className="h-5 w-5" />, label: "Instagram" },
                { icon: <Linkedin className="h-5 w-5" />, label: "LinkedIn" },
              ].map((social) => (
                <Link
                  key={social.label}
                  href="#"
                  className="text-muted-foreground hover:text-primary transition-colors duration-300 transform hover:scale-110"
                >
                  {social.icon}
                  <span className="sr-only">{social.label}</span>
                </Link>
              ))}
            </div>
          </motion.div>
          <motion.div className="space-y-4" variants={item}>
            <div className="text-lg font-semibold">Company</div>
            <ul className="space-y-2">
              {[
                { href: "/about", label: "About Us" },
                { href: "/about", label: "Our Team" },
                { href: "/contact", label: "Careers" },
                { href: "/contact", label: "Contact" },
              ].map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 relative group"
                  >
                    {link.label}
                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>
          <motion.div className="space-y-4" variants={item}>
            <div className="text-lg font-semibold">Services</div>
            <ul className="space-y-2">
              {[
                { href: "/services", label: "Content Marketing" },
                { href: "/services", label: "SEO Optimization" },
                { href: "/services", label: "Social Media" },
                { href: "/services", label: "Email Marketing" },
              ].map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 relative group"
                  >
                    {link.label}
                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>
          <motion.div className="space-y-4" variants={item}>
            <div className="text-lg font-semibold">Legal</div>
            <ul className="space-y-2">
              {[
                { href: "/terms", label: "Terms of Service" },
                { href: "/privacy", label: "Privacy Policy" },
                { href: "/terms", label: "Cookie Policy" },
                { href: "/privacy", label: "GDPR" },
              ].map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 relative group"
                  >
                    {link.label}
                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>
        </motion.div>
        <motion.div
          className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          viewport={{ once: true }}
        >
          © {new Date().getFullYear()} GrowEasy Marketing. All rights reserved.
        </motion.div>
      </div>
    </footer>
  )
}

